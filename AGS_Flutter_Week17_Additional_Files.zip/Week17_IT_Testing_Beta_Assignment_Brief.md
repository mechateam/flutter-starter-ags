# Alta Global School: IT SHS (Grades 10 & 11)
# Sprint 3 Concluding Assignment Brief (Week 17)
# Google Classroom Posting Specification

* Teacher: Meldi  
* Target Classes: IT-10 [B], IT-10 [E], IT-10 [C], IT-11 [A], IT-10 [F]  
* Delivery Mode: 100% Online via Google Meet  
* Assignment Title: `[Sprint 3] Week 17: Version Beta Release & Peer Bug Report`  
* Total Points: 100 Points  
* Assessment Weighting: Targets 10% Testing & Debugging and 15% Team Collaboration  
* Due Date: Before each class's scheduled session in Week 17 (NOT Sunday):  
  - IT-10 [B]: Monday, November 9, 2026 at 23:59 WIB (Before Tuesday 08:40 class)  
  - IT-10 [E]: Tuesday, November 10, 2026 at 23:59 WIB (Before Wednesday 07:30 class)  
  - IT-10 [C]: Thursday, November 12, 2026 at 23:59 WIB (Before Friday 07:30 class)  
  - IT-11 [A]: Thursday, November 12, 2026 at 23:59 WIB (Before Friday 08:40 class)  
  - IT-10 [F]: Thursday, November 12, 2026 at 23:59 WIB (Before Friday 09:50 class)  

---

## 1. Assignment Purpose & Context

Over Weeks 14, 15, and 16, our student teams built the core features of their mobile applications: persistent local storage with `SharedPreferences`, dynamic CRUD list operations with `setState`, Material 3 inputs, and Strategy 2 two-tier navigation.

Week 17 concludes **Sprint 3** by addressing software quality, stability, and maintainability. In professional software engineering, writing code is only half the battle. High-performing teams battle-test their code through independent quality assurance, debug root causes using stack traces, implement defensive UI patterns, and refactor monolithic files into clean modular architecture.

In this concluding milestone, every student team will:
1. **Audit a Peer Team Application:** Conduct black-box stress testing against an assigned partner team's app to break confirmation bias.
2. **File a Standardized Bug Report:** Document discovered issues using `alta-global-school/IT/lib/bug_report_template.md` with clear reproduction steps and severity ratings (P1 Blocker, P2 Major, P3 Minor).
3. **Patch Root Causes Defensively:** Resolve reported defects by applying defensive patterns (keyboard scrolling safety, null coalescing, empty states).
4. **Refactor Project Structure:** Organize your repository into four clean layers (`models/`, `screens/`, `widgets/`, `services/`) with a slim `main.dart` under 50 lines.
5. **Publish Version Beta:** Verify zero analyzer warnings (`flutter analyze`), tag release `v0.3.0-beta`, and push the tags to GitHub.

---

## 2. Step-by-Step Student Instructions

### Step 1: Pair with Assigned Peer Team for Cross-Testing
During our Google Meet lab session, your team will receive an assigned partner team (e.g., Tasky pairs with PocketWise; ResQ pairs with HabitHero).
1. Obtain your partner team's GitHub repository link or APK build.
2. Run the application on your local emulator or physical device.
3. Conduct 15 minutes of black-box stress testing. Do not inspect their code beforehand.

### Step 2: Execute Stress Testing & Complete the Bug Report
Execute the following edge case tests against your peer's application:
* **Empty Field Submission:** Tap add or save buttons with blank inputs.
* **Long Text Ingestion:** Type 150 characters into text fields to test wrapping and card boundaries.
* **Soft Keyboard Occlusion:** Tap inputs near the bottom of the screen to verify scrolling without `RenderFlex` overflows.
* **Rapid Multi-Tapping:** Tap action buttons three times in quick succession.
* **Null Storage Recovery:** Clear app cache or restart emulator to verify cold-start stability.

Fill out `alta-global-school/IT/lib/bug_report_template.md` documenting at least 2 distinct defects. Specify:
* Clear summary and severity (P1 Blocker, P2 Major, P3 Minor).
* Numbered step-by-step reproduction instructions.
* Expected behavior versus actual outcome.
* Screenshot, video link, or terminal stack trace.

Share the completed bug report with your partner team and include it in your submission.

### Step 3: Patch Received Defects & Apply Defensive UI
Review the bug report your team received from your testing partner. Apply defensive programming techniques to patch all P1 and P2 issues:
1. **Fix RenderFlex Overflows:** Wrap forms in `SingleChildScrollView` to prevent keyboard collisions.
2. **Fix Null Crashes:** Use null coalescing (`??`) to supply default fallbacks for storage keys.
3. **Add Empty State Views:** If your list is empty, show a friendly placeholder card instead of a blank void.
4. **Guard Input Ranges:** Add validation checks before adding items or accessing list indices.

### Step 4: Refactor Codebase into 4-Layer Architecture
Reorganize your `lib/` directory into four modular packages:
* `lib/models/`: Pure Dart classes for data entities (e.g., `task_item.dart`).
* `lib/services/`: Storage and business logic helper functions (e.g., `storage_service.dart`).
* `lib/widgets/`: Reusable UI components exceeding 40 lines (e.g., `item_card.dart`, `empty_state_view.dart`).
* `lib/screens/`: Top-level page Scaffolds (e.g., `welcome_screen.dart`, `dashboard_screen.dart`).
* `lib/main.dart`: Slim entrypoint under 50 lines.

Run the analyzer in your terminal:
```bash
flutter analyze
```
Ensure the analyzer returns: `No issues found!`.

### Step 5: Tag Version Beta Release `v0.3.0-beta` & Push to GitHub
1. Update `pubspec.yaml` version:
   ```yaml
   version: 0.3.0+3
   ```
2. Commit your fixes and refactoring:
   ```bash
   git add .
   git commit -m "fix: resolve peer bugs and refactor to 4-layer architecture"
   ```
3. Create an annotated release tag:
   ```bash
   git tag -a v0.3.0-beta -m "Sprint 3 Version Beta Release: hardened core flows and clean architecture"
   ```
4. Push your commit and tags:
   ```bash
   git push origin main
   git push origin v0.3.0-beta
   ```

---

## 3. Team App Customization Notice

KantinKu is strictly Meldi's teacher demonstration app, not the students' app. Every student team must test, debug, refactor, and release their own distinct team application:

| Team Application | Product Domain | Example Primary Entity |
|---|---|---|
| **Tasky** | Student Task & Productivity Manager | Task items, deadlines, priority tags |
| **PocketWise** | Student Allowance & Expense Tracker | Daily expenses, budget categories, IDR amounts |
| **ResQ** | Campus Emergency & Medical Safety | Emergency contacts, medical alerts, speed dials |
| **HabitHero** | Daily Habit Tracker & Streaks | Habit goals, daily checklists, completion streaks |
| **BullsEye** | Academic Target & Grade Tracker | Course goals, assignment targets, progress scores |

---

## 4. Assessment Rubric (100 Points Total)

| Evaluation Criterion | Exemplary (25 Points) | Proficient (15 Points) | Incomplete (0 Points) |
|---|---|---|---|
| **1. Cross-Testing & Bug Hunting (25 pts)** | Rigorous stress-testing of peer app covering empty states, long text, and keyboard interactions; uncovers genuine edge cases. | Basic testing conducted covering only happy-path scenarios with minimal edge case probing. | No peer testing conducted. |
| **2. Bug Report Quality & Reproduction (25 pts)** | Complete report using AGS template with deterministic reproduction steps, accurate severity (P1-P3), and evidence. | Bug report filed but lacks detailed reproduction steps, evidence, or severity classification. | No bug report filed. |
| **3. Bug Fixing & Clean Refactoring (25 pts)** | All reported P1/P2 defects patched with defensive code; project modularized into 4 clean layers; 0 analyzer warnings. | Defects partially resolved; code remains in a monolithic single file; minor warnings present. | Bugs unaddressed; syntax errors prevent app compilation. |
| **4. GitHub Tagged Release v0.3.0-beta (25 pts)** | Annotated git tag `v0.3.0-beta` pushed to GitHub; clean commit history; `pubspec.yaml` version updated to `0.3.0+3`. | Code pushed to main branch but missing annotated git release tag or version update. | No code or tags pushed to GitHub repository. |

---

## 5. Google Classroom Submission Specification

Submit the following items directly on Google Classroom before your scheduled class session:

1. **GitHub Repository URL:** Public link to your team repository.
2. **Version Beta Tag URL:** Direct link to your tagged release (e.g., `https://github.com/team/app/releases/tag/v0.3.0-beta`).
3. **Completed Bug Report:** Either attach your Markdown file (`bug_report_template.md`) or paste the report text for the peer team you tested.
4. **Peer Team Name:** Clearly state which team's application your team tested.

All questions regarding testing protocols or git tagging can be asked during our live Google Meet sessions or posted in the Classroom discussion stream.

Signed,  
Meldi  
IT Master Teacher  
Alta Global School
