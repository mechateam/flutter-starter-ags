# Week 17: Sprint 3 Concluding Milestone: Testing, Debugging, Refactoring & Version Beta Release

Welcome to Week 17 of our Mobile App Development Bootcamp at Alta Global School!  
* Teacher: Meldi  
* Target Classes: Grade 10 (IT-10B, IT-10C, IT-10E, IT-10F) & Grade 11 (IT-11A)  
* Delivery Mode: 100% Online via Google Meet  
* Syllabus Topic: Sprint 3 Concluding Milestone: "Testing & Code Improvement"  
* Milestone Deliverables: Peer Bug Report (`bug_report_template.md`) & Version Beta Release (`v0.3.0-beta`)  
* Assessment Weighting: Targets 10% Testing & Debugging and 15% Team Collaboration  

---

## 1. Concluding Sprint 3: From Feature Assembly to Production Stability

Over the last three weeks, our student teams built the core engine of their mobile applications:
* **Week 14:** Persistent storage with `SharedPreferences` to defeat app amnesia.
* **Week 15:** Dynamic CRUD lists with `setState` and `ListView.builder`.
* **Week 16:** Material 3 packages from `pub.dev`, `intl` date and currency formatting, and Strategy 2 two-tier navigation.

Writing features, however, is only the first half of software engineering. An application that crashes when an input is empty, freezes when a user opens the keyboard, or scatters 600 lines of spaghetti code into a single file is not ready for real users.

Week 17 is our dedicated Quality Assurance and Refactoring Sprint. Your team will:
1. Stress-test a peer team application using a structured bug bounty protocol.
2. File a formal Bug Report using our standardized template.
3. Decode Flutter stack traces and DevTools logs to pinpoint root causes.
4. Implement defensive UI patterns that gracefully handle bad inputs, small screens, and null values.
5. Refactor your project into a professional 4-layer architecture (`models/`, `screens/`, `widgets/`, `services/`).
6. Tag and publish your official Version Beta release (`v0.3.0-beta`) to GitHub.

---

## 2. The Core Concept: The Test Pilot Mindset

Why do software engineers never test their own code alone?

Because of **confirmation bias**. When you write code, your subconscious mind knows every fragile assumption you made. Your fingers naturally type perfect dates, short names, and clean inputs. You never double-tap buttons rapidly or leave forms blank.

Consider how aerospace engineers test a newly built aircraft:
* Test pilots do not take off, fly in gentle circles on sunny days, and land smoothly just to look good.
* They take the jet into thin air, deliberately stall the engines, put the aircraft into high-G dives, and test the recovery systems to their breaking points.
* Bridge inspectors do not lightly walk across a new suspension bridge; they drive lines of 50-ton gravel trucks onto the center span to measure deflection under maximum stress.

In software engineering, finding a bug is not a failure; it is a **victory**. Every defect your peer team uncovers during testing is a saved reputation before our Sprint 4 public showcase demo.

---

## 3. Part 1: Peer Cross-Testing Protocol

During our Google Meet lab session, your team will pair with an assigned partner team to conduct a 15-minute black-box bug bounty.

### The Ground Rules
1. **Black-Box Testing:** Do not look at your peer team source code initially. Test their application purely from the perspective of an inquisitive, unpredictable end-user.
2. **Stress Ingestion Scenarios:** Run through these specific torture tests:
   * **The Empty Submit Test:** Tap every add, save, or checkout button with blank text fields. Does the app crash, or does it display helpful validation text?
   * **The Novelist Input Test:** Type a 150-character string into the item title box. Does the text wrap cleanly, truncate with ellipsis, or break out of the card with yellow-and-black overflow stripes?
   * **The Keyboard Occlusion Test:** Tap into an input field at the bottom of the screen. When the soft keyboard pops up, does the screen scroll smoothly, or does it trigger a `RenderFlex overflowed` error?
   * **The Rapid Double-Tap Test:** Tap an action button three times in rapid succession. Does it spawn duplicate items or crash the state machine?
   * **The Clean State Test:** Clear the app cache or restart the emulator. Does the app launch cleanly without crashing on missing stored keys?
3. **Document Everything:** Whenever an error occurs, take a screenshot or copy the terminal stack trace immediately.

---

## 4. Part 2: Bug Severity Classification

When filing defects in `alta-global-school/IT/lib/bug_report_template.md`, classify each issue using our standard three-tier severity scale:

### P1: Blocker (Crash / Fatal Data Loss)
* **Definition:** The application terminates unexpectedly, freezes indefinitely, shows the Flutter Red Screen of Death, or corrupts stored data.
* **Examples:** `Null check operator used on a null value`, `RangeError (index): Invalid value`, app crashing on launch.
* **Protocol:** All P1 bugs must be resolved immediately before tagging Version Beta.

### P2: Major (Feature Failure / Broken Flow)
* **Definition:** A primary user story fails to complete, but the app remains alive.
* **Examples:** Tapping the delete button does not remove the item, filter chips do not update the displayed list, or local storage fails to retain data after an app restart.
* **Protocol:** Must be patched or provided with a defensive workaround before Beta release.

### P3: Minor (Cosmetic / Layout Glitch)
* **Definition:** Visual imperfections, awkward padding, or typographical errors that do not block feature functionality.
* **Examples:** Typo in placeholder hint text, badge counter slightly misaligned, or unformatted timestamp strings.
* **Protocol:** Documented in the bug report; prioritized for Sprint 4 visual polish.

---

## 5. Part 3: Debugging Forensics (Decoding Stack Traces)

When Flutter crashes and shows the Red Screen of Death, follow this three-step forensic procedure:

```text
════════ Exception caught by widgets library ═══════════════════════════════════
The following RangeError was thrown building DashboardScreen:
RangeError (index): Invalid value: Valid value range is empty: 0

The relevant error-causing widget was:
  DashboardScreen
  package:team_app/screens/dashboard_screen.dart:142:25
════════════════════════════════════════════════════════════════════════════════
```

### Step 1: Read the Top Exception Message
Look at the first line below the banner. It states exactly WHAT broke:
* `RangeError (index): Invalid value: Valid value range is empty: 0`: The code tried to access item 0 of a list that has 0 items!
* `Null check operator used on a null value`: The code used `!` on a variable that was null.
* `A RenderFlex overflowed by 48 pixels on the bottom`: A Column was pushed down by the keyboard and ran out of room.

### Step 2: Trace Down to Your Project Files
Flutter prints dozens of internal framework lines (`package:flutter/src/widgets/...`). Ignore them!
Scan down until you find your project name:
`package:team_app/screens/dashboard_screen.dart:142:25`
This tells you the exact file (`dashboard_screen.dart`) and the exact line number (`142`) where your code triggered the crash.

### Step 3: Inspect the Widget Tree in DevTools
In VS Code, open the Command Palette (`Cmd+Shift+P` or `Ctrl+Shift+P`), type **Flutter: Open DevTools**, and open the **Widget Inspector**. Click **Select Widget Mode** and tap the broken element on your emulator to view its runtime constraints and padding.

---

## 6. Part 4: Four Defensive UI Patterns

Apply these four proven patterns to harden your team mobile application:

### Pattern 1: Keyboard-Safe Scrolling (Fixing RenderFlex Overflows)
**The Bug:** When the user taps a text input, the on-screen keyboard pops up (taking ~300 pixels of vertical space) and pushes your layout off the bottom of the screen.  
**Defensive Fix:** Wrap your form Column in a `SingleChildScrollView`:

```dart
// Before (Fragile):
Scaffold(
  body: Column(
    children: [
      HeaderWidget(),
      CustomInputField(),
      SubmitButton(),
    ],
  ),
);

// After (Defensive):
Scaffold(
  body: SafeArea(
    child: SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          HeaderWidget(),
          CustomInputField(),
          SubmitButton(),
        ],
      ),
    ),
  ),
);
```

### Pattern 2: Null Coalescing Fallbacks (`??`)
**The Bug:** On fresh installs, `SharedPreferences.getString('user_name')` returns `null`. Calling `.toUpperCase()` on `null` crashes the entire screen.  
**Defensive Fix:** Always provide a default fallback using `??`:

```dart
// Defensive fallback:
final String savedName = prefs.getString('user_name') ?? 'Guest';
final DateTime displayDate = item.date ?? DateTime.now();
```

### Pattern 3: Informative Empty State Placeholders
**The Bug:** When a user opens the app for the first time, `_items.isEmpty` is true. `ListView.builder` renders an empty void, making users think the app froze.  
**Defensive Fix:** Render an inviting placeholder when the collection has no items:

```dart
Widget buildItemList() {
  if (_items.isEmpty) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_outlined, size: 64, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text(
              'No items yet!',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey[600]),
            ),
            const SizedBox(height: 8),
            Text(
              'Add your first item using the button above.',
              style: TextStyle(color: Colors.grey[500]),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  return ListView.builder(
    itemCount: _items.length,
    itemBuilder: (context, index) => ItemCard(item: _items[index]),
  );
}
```

### Pattern 4: Text Overflow Guardrails
**The Bug:** If an item title contains 100 characters, it pushes trailing action icons off the right edge of the phone.  
**Defensive Fix:** Wrap the title in `Expanded` and set `TextOverflow.ellipsis`:

```dart
Row(
  children: [
    Icon(Icons.label_outline),
    const SizedBox(width: 12),
    Expanded(
      child: Text(
        item.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
    ),
    IconButton(
      icon: const Icon(Icons.delete_outline, color: Colors.red),
      onPressed: () => _deleteItem(index),
    ),
  ],
)
```

---

## 7. Part 5: Clean Code Refactoring (The 4-Layer Architecture)

Having a 600-line single file creates merge conflicts and makes debugging a nightmare. Refactor your project into this modular directory structure:

```text
lib/
├── main.dart                 # Lightweight entrypoint (< 50 lines)
├── models/
│   └── item_model.dart       # Pure Dart data schemas
├── screens/
│   ├── welcome_screen.dart   # Onboarding / shell screen
│   └── dashboard_screen.dart # Core feature engine
├── widgets/
│   ├── item_card.dart        # Extracted reusable card widget
│   ├── empty_state_view.dart # Friendly zero-state placeholder
│   └── category_chip_bar.dart# Filter chips component
└── services/
    └── storage_service.dart  # SharedPreferences read/write logic
```

### Layer Rules
1. **`lib/models/`:** Contains only class declarations with typed properties. No `Widget` or `BuildContext` imports.
2. **`lib/services/`:** Wraps asynchronous platform operations like `SharedPreferences`. Exposes clean functions like `Future<List<Item>> loadItems()` and `Future<void> saveItems(List<Item> items)`.
3. **`lib/widgets/`:** Any UI component that takes more than 40 lines of code should be extracted into its own `StatelessWidget`. Accepts data via constructor parameters.
4. **`lib/screens/`:** Assembles widgets and manages screen-level state.
5. **`lib/main.dart`:** Kept under 50 lines. Initializes `MaterialApp`, sets theme colors, and specifies the initial route.

---

## 8. Part 6: Version Beta Release Protocol (`v0.3.0-beta`)

Once your team has patched all reported P1 and P2 defects and refactored your files, publish your official Version Beta release.

### Step 1: Update Version in `pubspec.yaml`
Open `pubspec.yaml` and update the version string:

```yaml
name: team_app
description: "A mobile application built by Alta Global School students."
version: 0.3.0+3
```

### Step 2: Run Static Code Analysis
Ensure your codebase has zero syntax errors or lint warnings:

```bash
flutter analyze
```
Confirm the output reads: `No issues found!`.

### Step 3: Git Commit and Tag
Commit all your refactored code and create an annotated git tag:

```bash
# 1. Stage all changes
git add .

# 2. Commit bug fixes and refactoring
git commit -m "fix: resolve peer bugs and refactor to 4-layer architecture"

# 3. Create annotated Version Beta release tag
git tag -a v0.3.0-beta -m "Sprint 3 Version Beta Release: hardened core flows and clean architecture"

# 4. Push commit and tags to GitHub
git push origin main
git push origin v0.3.0-beta
```

---

## 9. Teacher Demonstration Reference: How KantinKu Patched 3 Bugs

KantinKu is Meldi's classroom reference demo, not the students' app. During class, Meldi demonstrates how KantinKu was hardened:

| Demonstration Defect | Root Cause | Teacher Demo Fix | Takeaway for Your Team App |
|---|---|---|---|
| **1. Keyboard Bottom Overflow** | Fixed Column in bottom sheet modal without scroll capability | Wrapped body in `SingleChildScrollView` with `viewInsets.bottom` padding | Protect all input dialogs from soft keyboard occlusion |
| **2. Empty Cart Checkout Crash** | Called `cartItems.first` without verifying if cart was empty | Added guard clause: `if (cart.isEmpty) return showSnackBar('Cart is empty!');` | Never access collection indices without checking length |
| **3. Null Profile Name Crash** | `SharedPreferences` returned null on first app launch | Applied null coalescing fallback: `final name = prefs.getString('student_name') ?? 'Friend';` | Always provide clean default values for external storage |

Study these demonstration patterns, then apply the equivalent defensive techniques to your team mobile application (e.g., Tasky, PocketWise, ResQ, HabitHero, BullsEye).

---

## 10. Deliverables Checklist & Submission Instructions

Before your scheduled class session in Week 17, ensure your team has completed:

- [ ] **Deliverable 1 (Cross-Testing):** Audited your peer team app across empty states, long text, and keyboard interactions.
- [ ] **Deliverable 2 (Bug Report):** Completed `bug_report_template.md` with at least 2 documented issues, clear reproduction steps, and severity tags.
- [ ] **Deliverable 3 (Bug Fixing & Refactoring):** Patched all received P1/P2 defects and reorganized code into `models/`, `screens/`, `widgets/`, and `services/`.
- [ ] **Deliverable 4 (Version Beta Tag):** Pushed tag `v0.3.0-beta` to GitHub with 0 `flutter analyze` issues.
- [ ] **Submission Link:** Post your GitHub repository URL and link to the tagged release on Google Classroom under `[Sprint 3] Week 17: Version Beta Release & Peer Bug Report`.
